// Isi dengan Project URL dan anon/publishable key dari Supabase.
// Jangan pernah menaruh service_role key di file frontend.
window.APP_CONFIG = {
  SUPABASE_URL: "https://YOUR-PROJECT.supabase.co",
  SUPABASE_ANON_KEY: "YOUR_SUPABASE_ANON_OR_PUBLISHABLE_KEY"
};